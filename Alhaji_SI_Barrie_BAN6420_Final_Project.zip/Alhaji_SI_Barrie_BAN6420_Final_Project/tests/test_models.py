from datetime import datetime, timezone

from models import EXPENSE_CATEGORIES, User


def test_user_round_trip_and_csv_row():
    user = User(
        age=40,
        gender="Female",
        total_income=75000,
        expenses={"utilities": 5000, "healthcare": 1200},
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )

    document = user.to_document()
    restored = User.from_document(document)
    row = restored.to_csv_row()

    assert restored.total_expenses == 6200
    assert set(restored.expenses) == set(EXPENSE_CATEGORIES)
    assert row["utilities"] == 5000
    assert row["school_fees"] == 0
    assert row["created_at"].startswith("2026-07-01")
