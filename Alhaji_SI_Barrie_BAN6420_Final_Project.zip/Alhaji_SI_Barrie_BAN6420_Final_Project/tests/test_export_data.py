import csv
from datetime import datetime, timezone

from export_data import export_documents


def test_export_documents_writes_flat_csv(tmp_path):
    documents = [
        {
            "age": 35,
            "gender": "Male",
            "total_income": 62000,
            "expenses": {
                "utilities": 4200,
                "entertainment": 1800,
                "school_fees": 0,
                "shopping": 2200,
                "healthcare": 900,
            },
            "created_at": datetime(2026, 7, 1, tzinfo=timezone.utc),
        }
    ]
    output = tmp_path / "survey.csv"

    count = export_documents(documents, output)

    with output.open(encoding="utf-8") as file:
        rows = list(csv.DictReader(file))
    assert count == 1
    assert rows[0]["age"] == "35"
    assert rows[0]["healthcare"] == "900.0"
    assert rows[0]["total_expenses"] == "9100.0"
