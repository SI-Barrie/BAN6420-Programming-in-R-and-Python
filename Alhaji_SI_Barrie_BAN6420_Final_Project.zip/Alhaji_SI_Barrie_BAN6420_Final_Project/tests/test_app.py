from types import SimpleNamespace

from app import create_app


class FakeCollection:
    def __init__(self):
        self.documents = []

    def insert_one(self, document):
        self.documents.append(document)
        return SimpleNamespace(inserted_id="test-reference-001")


class FakeDatabase:
    def __init__(self, collection):
        self.collection = collection

    def __getitem__(self, _name):
        return self.collection


class FakeAdmin:
    @staticmethod
    def command(name):
        assert name == "ping"
        return {"ok": 1}


class FakeMongoClient:
    def __init__(self):
        self.collection = FakeCollection()
        self.admin = FakeAdmin()

    def __getitem__(self, _name):
        return FakeDatabase(self.collection)


def build_client():
    mongo = FakeMongoClient()
    app = create_app(
        {
            "TESTING": True,
            "WTF_CSRF_ENABLED": False,
            "MONGO_CLIENT": mongo,
            "SECRET_KEY": "test-key",
        }
    )
    return app.test_client(), mongo


def test_survey_page_contains_required_fields():
    client, _mongo = build_client()
    response = client.get("/")

    assert response.status_code == 200
    assert b'name="age"' in response.data
    assert b'name="gender"' in response.data
    assert b'name="total_income"' in response.data
    assert b'name="healthcare_selected"' in response.data


def test_valid_submission_is_stored_in_mongodb_shape():
    client, mongo = build_client()
    response = client.post(
        "/",
        data={
            "age": "42",
            "gender": "Female",
            "total_income": "85000",
            "utilities_selected": "on",
            "utilities_amount": "6200",
            "healthcare_selected": "on",
            "healthcare_amount": "1400",
        },
    )

    assert response.status_code == 200
    assert b"Thank you for participating" in response.data
    assert len(mongo.collection.documents) == 1
    stored = mongo.collection.documents[0]
    assert stored["age"] == 42
    assert stored["expenses"]["utilities"] == 6200
    assert stored["expenses"]["school_fees"] == 0


def test_invalid_submission_returns_errors_and_does_not_store():
    client, mongo = build_client()
    response = client.post(
        "/",
        data={
            "age": "not-an-age",
            "gender": "",
            "total_income": "-4",
        },
    )

    assert response.status_code == 200
    assert b"Please correct the following" in response.data
    assert not mongo.collection.documents


def test_health_endpoint_checks_database():
    client, _mongo = build_client()
    response = client.get("/health")

    assert response.status_code == 200
    assert response.get_json() == {"database": "connected", "status": "healthy"}
