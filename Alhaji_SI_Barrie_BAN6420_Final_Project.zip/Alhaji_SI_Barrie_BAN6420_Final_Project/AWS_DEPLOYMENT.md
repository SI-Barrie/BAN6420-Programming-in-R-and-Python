# AWS Deployment Design and Readiness Record

## Deployment position

I designed this Flask healthcare survey for deployment on AWS Elastic
Beanstalk with MongoDB Atlas as the hosted database. I completed the
application-level deployment configuration, production entry point, dependency
definition, environment-variable design, health check, and verification plan.

I was unable to provision a live AWS environment before submission because the
development environment available for the assignment did not include access to
an authorised AWS account or credentials with permission to create Elastic
Beanstalk, EC2, S3, IAM-connected, networking, and related cloud resources.
Because these services may generate continuing charges, I did not consider it
appropriate to create billable infrastructure without explicit approval from
the account holder or institution. The remaining work is therefore limited to
account-specific resource provisioning rather than application development.

## Architecture I selected

I selected the following deployment architecture:

1. AWS Elastic Beanstalk hosts the Flask application behind its managed proxy.
2. Gunicorn serves the WSGI object exposed as `application` in
   `application.py`.
3. Elastic Beanstalk supplies production settings through runtime environment
   variables rather than source-code credentials.
4. MongoDB Atlas stores survey records in the `healthcare_survey` database and
   `participants` collection.
5. The `/health` route confirms whether the deployed application can connect
   to MongoDB.

This design separates the web application from the database and avoids placing
passwords, connection strings, or secret keys in the submitted files.

## Deployment-ready files I developed

| File | Purpose |
| --- | --- |
| `application.py` | Exposes the WSGI callable expected by Elastic Beanstalk |
| `Procfile` | Starts Gunicorn with two workers and four threads |
| `requirements.txt` | Lists only the production Python dependencies |
| `.ebextensions/01_environment.config` | Defines the WSGI path and nginx proxy |
| `.ebignore` | Excludes tests, notebooks, charts, and local data from the cloud bundle |
| `.env.example` | Documents the required configuration keys without real credentials |
| `app.py` | Reads secure settings from the environment and provides `/health` |

I also configured the application to reject the default development secret
when `FLASK_ENV=production`. This prevents an accidental production deployment
with a known session key.

## Account-specific prerequisites

The live provisioning stage requires the following items from an authorised
account holder:

- An AWS account permitted to create Elastic Beanstalk resources.
- Configured AWS CLI and Elastic Beanstalk CLI access.
- An approved AWS Region and cost-management arrangement.
- A MongoDB Atlas cluster and a database user with limited read/write access.
- Atlas network access configured for the AWS application's outbound traffic.

These prerequisites are intentionally not included in the project because they
contain account-specific or sensitive information.

## MongoDB configuration I designed

I designed the production database connection around a MongoDB Atlas URI with
the following structure:

```text
mongodb+srv://USERNAME:PASSWORD@CLUSTER.mongodb.net/?retryWrites=true&w=majority
```

The username, URL-encoded password, and cluster name would be supplied only in
the authorised deployment environment. I would grant the database user access
only to the `healthcare_survey` database and configure network access as
narrowly as the AWS architecture permits.

## AWS deployment workflow I prepared

The following is the command sequence I prepared for an authorised deployment
session. I would run it from the project root after configuring the AWS account:

```bash
python -m pip install --upgrade awsebcli
aws configure
aws sts get-caller-identity
eb init
eb create healthcare-survey-env --single
```

During `eb init`, I would select the approved AWS Region, create or select an
application named `healthcare-survey`, and choose the current supported Python
platform on Amazon Linux. I selected a single-instance environment for a
short-lived academic demonstration because it is less complex than a
load-balanced production architecture. For a real production system, I would
add load balancing, autoscaling, monitoring, backups, private networking, and
a formal security review.

## Runtime environment variables I specified

I identified the following Elastic Beanstalk runtime variables:

| Variable | Intended value |
| --- | --- |
| `SECRET_KEY` | A newly generated high-entropy secret |
| `MONGO_URI` | The authorised MongoDB Atlas connection string |
| `MONGO_DB_NAME` | `healthcare_survey` |
| `MONGO_COLLECTION` | `participants` |
| `FLASK_ENV` | `production` |

I would generate the session secret locally with:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

I would store these values as Elastic Beanstalk runtime settings, preferably
using AWS Secrets Manager or Systems Manager Parameter Store for sensitive
values where supported. I would not place live credentials in `.env`, the ZIP
file, `.ebextensions`, or a Git repository.

## Deployment and verification procedure I designed

After the environment variables were configured, I would deploy and inspect
the environment with:

```bash
eb deploy
eb status
eb open
```

My verification procedure would consist of the following checks:

1. I would confirm that the public survey page loads over the Elastic
   Beanstalk URL.
2. I would submit one clearly marked test response.
3. I would open the `/health` endpoint and confirm the response below:

```json
{"database":"connected","status":"healthy"}
```

4. I would confirm in MongoDB Atlas that the test document contains `age`,
   `gender`, `total_income`, `expenses`, `total_expenses`, and `created_at`.
5. I would delete the clearly marked test document before analysing live
   responses.
6. I would record the verified public URL as deployment evidence for the
   assignment.

## Update and resource-termination plan

I designed the update workflow so that every code change would be tested before
redeployment:

```bash
pytest -q
eb deploy
```

Because the proposed environment is intended only for an academic
demonstration, I would terminate it immediately after the assignment had been
assessed to prevent unnecessary charges:

```bash
eb terminate healthcare-survey-env
```

I would confirm termination in the AWS console and retain or remove the
MongoDB Atlas cluster according to the agreed data-retention decision.

## Technical references used in my deployment design

- [Deploying a Flask application to Elastic Beanstalk](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/create-deploy-python-flask.html)
- [Elastic Beanstalk environment variables](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/environments-cfg-softwaresettings.html)
- [MongoDB Atlas connection guide](https://www.mongodb.com/docs/atlas/connect-your-application/)

These references informed the configuration included in the project. The
deployment record is sufficiently detailed for the application to be
provisioned from an authorised AWS account without redesigning the source code.
