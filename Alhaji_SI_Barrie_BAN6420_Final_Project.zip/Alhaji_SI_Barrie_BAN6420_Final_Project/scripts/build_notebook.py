"""Build and execute the final-project analysis notebook."""

from __future__ import annotations

import ast
import base64
import io
import os
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from typing import Any

import nbformat as nbf


ROOT = Path(__file__).resolve().parents[1]
NOTEBOOK_PATH = ROOT / "notebook" / "Healthcare_Spending_Analysis.ipynb"


def markdown(text: str):
    return nbf.v4.new_markdown_cell(text.strip())


def code(text: str):
    return nbf.v4.new_code_cell(text.strip())


def build_notebook():
    notebook = nbf.v4.new_notebook()
    notebook["metadata"] = {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3",
        },
        "language_info": {"name": "python", "version": "3.12"},
    }

    notebook["cells"] = [
        markdown(
            """
# Final Project: Healthcare Income and Spending Analysis

**Student:** Alhaji Sorie Ibrahim Barrie  
**Course:** BAN6420 - R and Python  
**Project:** Flask Healthcare Application

## Objective

I developed a Flask survey to collect participants' age, gender, total income,
and spending in five categories. The application stores each response in
MongoDB. I then used my `User` class and `export_data.py` to loop through the
MongoDB records and create a flat CSV file for analysis.

This submitted notebook uses the included **synthetic demonstration export**.
It contains no real participant information and allows the complete analysis
to be reproduced before live survey responses are available.
            """
        ),
        markdown(
            """
## 1. Import libraries and load the exported CSV

The code below locates the project folder whether Jupyter is started from the
project root or from the `notebook` folder. It also creates the chart output
directory if necessary.
            """
        ),
        code(
            """
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from matplotlib.ticker import FuncFormatter

sns.set_theme(style="whitegrid", context="notebook")
plt.rcParams.update({
    "figure.figsize": (11, 6.5),
    "figure.dpi": 110,
    "axes.titleweight": "bold",
    "axes.titlesize": 15,
    "axes.labelsize": 11,
})

working_directory = Path.cwd()
if (working_directory / "data").exists():
    project_root = working_directory
elif (working_directory.parent / "data").exists():
    project_root = working_directory.parent
else:
    raise FileNotFoundError("Start Jupyter from the project root or notebook folder.")

live_data_path = project_root / "data" / "healthcare_survey.csv"
sample_data_path = project_root / "data" / "healthcare_survey_sample.csv"
data_path = live_data_path if live_data_path.exists() else sample_data_path
charts_path = project_root / "charts"
charts_path.mkdir(exist_ok=True)

df = pd.read_csv(data_path, parse_dates=["created_at"])
print(f"Loaded {len(df):,} participant records from {data_path.name}.")
df.head()
            """
        ),
        markdown(
            """
## 2. Check data quality and summarize the sample

I verify that the required columns are present, convert the analysis fields to
numeric values, and check for missing or duplicate records before plotting.
            """
        ),
        code(
            """
expense_categories = [
    "utilities",
    "entertainment",
    "school_fees",
    "shopping",
    "healthcare",
]
required_columns = ["age", "gender", "total_income", *expense_categories]
missing_columns = sorted(set(required_columns) - set(df.columns))
assert not missing_columns, f"Missing required columns: {missing_columns}"

numeric_columns = ["age", "total_income", *expense_categories, "total_expenses"]
df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric, errors="coerce")

quality_summary = pd.DataFrame({
    "measure": ["Rows", "Duplicate rows", "Missing required values", "Age range"],
    "result": [
        len(df),
        int(df.duplicated().sum()),
        int(df[required_columns].isna().sum().sum()),
        f"{int(df['age'].min())}-{int(df['age'].max())}",
    ],
})
quality_summary
            """
        ),
        code(
            """
summary = df[["age", "total_income", "total_expenses", *expense_categories]].describe().T
summary[["count", "mean", "50%", "min", "max"]].round(2)
            """
        ),
        markdown(
            """
## 3. Ages with the highest income

To avoid selecting one unusually high-income respondent, I calculate the
**average income for each exact age**. I then rank and display the ten ages with
the highest average income. The participant count is retained for context.
            """
        ),
        code(
            """
income_by_age = (
    df.groupby("age", as_index=False)
      .agg(
          average_income=("total_income", "mean"),
          median_income=("total_income", "median"),
          participants=("total_income", "size"),
      )
      .sort_values("average_income", ascending=False)
)

top_income_ages = income_by_age.head(10).sort_values("average_income")
top_income_ages.sort_values("average_income", ascending=False).round(2)
            """
        ),
        code(
            """
fig, ax = plt.subplots(figsize=(11, 6.5))
bars = ax.barh(
    top_income_ages["age"].astype(str),
    top_income_ages["average_income"],
    color="#0f766e",
)
ax.set_title("Top 10 Ages by Average Total Income")
ax.set_xlabel("Average total income (USD)")
ax.set_ylabel("Age")
ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"${value/1000:,.0f}K"))
ax.grid(axis="x", alpha=0.25)
ax.grid(axis="y", visible=False)

for bar, value in zip(bars, top_income_ages["average_income"]):
    ax.text(
        value + top_income_ages["average_income"].max() * 0.012,
        bar.get_y() + bar.get_height() / 2,
        f"${value:,.0f}",
        va="center",
        fontsize=9,
    )

ax.set_xlim(0, top_income_ages["average_income"].max() * 1.18)
sns.despine(left=True, bottom=True)
fig.tight_layout()

age_chart = charts_path / "01_ages_highest_income.png"
fig.savefig(age_chart, dpi=300, bbox_inches="tight", facecolor="white")
print(f"Chart exported to: {age_chart.relative_to(project_root)}")
plt.show()
            """
        ),
        markdown(
            """
## 4. Gender distribution across spending categories

I reshape the five expense columns into a long format and calculate the average
amount spent in each category for every gender group. A grouped bar chart makes
the category patterns directly comparable while avoiding distortion from
unequal group sizes.
            """
        ),
        code(
            """
spending_long = df.melt(
    id_vars=["gender"],
    value_vars=expense_categories,
    var_name="spending_category",
    value_name="amount",
)
spending_long["spending_category"] = (
    spending_long["spending_category"]
    .str.replace("_", " ")
    .str.title()
)

gender_category_spending = (
    spending_long.groupby(["gender", "spending_category"], as_index=False)["amount"]
                 .mean()
)
gender_category_spending.pivot(
    index="spending_category", columns="gender", values="amount"
).round(2)
            """
        ),
        code(
            """
fig, ax = plt.subplots(figsize=(12, 7))
sns.barplot(
    data=gender_category_spending,
    x="spending_category",
    y="amount",
    hue="gender",
    palette=["#0f766e", "#2563a5", "#d97706", "#7c3aed"],
    ax=ax,
)
ax.set_title("Average Spending by Gender and Category")
ax.set_xlabel("Spending category")
ax.set_ylabel("Average amount (USD)")
ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"${value:,.0f}"))
ax.grid(axis="y", alpha=0.25)
ax.grid(axis="x", visible=False)
ax.legend(title="Gender", frameon=False, ncols=2)
sns.despine(left=True, bottom=True)
fig.tight_layout()

gender_chart = charts_path / "02_gender_spending_categories.png"
fig.savefig(gender_chart, dpi=300, bbox_inches="tight", facecolor="white")
print(f"Chart exported to: {gender_chart.relative_to(project_root)}")
plt.show()
            """
        ),
        markdown(
            """
## 5. Key findings from the demonstration data

The following cell reports the leading age and the highest average spending
category for each gender group. Because the submitted records are synthetic,
these findings demonstrate the analysis workflow and must not be interpreted
as evidence about the real healthcare market.
            """
        ),
        code(
            """
leading_age = income_by_age.iloc[0]
print(
    f"Age {int(leading_age['age'])} has the highest average income in the "
    f"demonstration data (${leading_age['average_income']:,.2f}).\\n"
)

leaders = (
    gender_category_spending.loc[
        gender_category_spending.groupby("gender")["amount"].idxmax()
    ]
    .sort_values("gender")
)
for row in leaders.itertuples(index=False):
    print(
        f"{row.gender}: {row.spending_category} is the highest average "
        f"category (${row.amount:,.2f})."
    )
            """
        ),
        markdown(
            """
## 6. Files prepared for the client presentation

The two figures were exported as 300-DPI PNG files in the `charts` folder:

1. `01_ages_highest_income.png`
2. `02_gender_spending_categories.png`

These high-resolution files can be inserted directly into PowerPoint. When
live survey data become available, I can run `export_data.py` and rerun this
notebook to update the results and charts.
            """
        ),
    ]
    return notebook


def _result_data(value: Any) -> dict[str, str]:
    """Create the plain-text and HTML representations used by Jupyter."""

    data = {"text/plain": repr(value)}
    html_renderer = getattr(value, "_repr_html_", None)
    if callable(html_renderer):
        html = html_renderer()
        if html:
            data["text/html"] = html
    return data


def _capture_open_figures(plt) -> list:
    """Convert all open Matplotlib figures to notebook image outputs."""

    outputs = []
    for figure_number in list(plt.get_fignums()):
        figure = plt.figure(figure_number)
        buffer = io.BytesIO()
        figure.savefig(buffer, format="png", dpi=110, bbox_inches="tight", facecolor="white")
        encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
        outputs.append(
            nbf.v4.new_output(
                output_type="display_data",
                data={"image/png": encoded, "text/plain": repr(figure)},
                metadata={},
            )
        )
        plt.close(figure)
    return outputs


def execute_in_process(notebook) -> None:
    """Execute code cells and embed their outputs without an external kernel.

    This produces the same persistent notebook artefact while remaining usable
    in build environments where opening a local Jupyter socket is restricted.
    """

    os.environ.setdefault("MPLBACKEND", "Agg")
    namespace: dict[str, Any] = {"__name__": "__main__", "__builtins__": __builtins__}
    original_directory = Path.cwd()
    execution_count = 0
    os.chdir(ROOT)
    try:
        for cell in notebook.cells:
            if cell.cell_type != "code":
                continue

            execution_count += 1
            cell.execution_count = execution_count
            cell.outputs = []
            stdout_buffer = io.StringIO()
            stderr_buffer = io.StringIO()
            figure_outputs: list = []

            if "plt" in namespace:
                namespace["plt"].show = lambda: figure_outputs.extend(
                    _capture_open_figures(namespace["plt"])
                )

            try:
                parsed = ast.parse(cell.source, filename=f"notebook-cell-{execution_count}")
                final_value = None
                with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
                    if parsed.body and isinstance(parsed.body[-1], ast.Expr):
                        leading = ast.Module(body=parsed.body[:-1], type_ignores=[])
                        ast.fix_missing_locations(leading)
                        exec(compile(leading, f"notebook-cell-{execution_count}", "exec"), namespace)
                        expression = ast.Expression(parsed.body[-1].value)
                        ast.fix_missing_locations(expression)
                        final_value = eval(
                            compile(expression, f"notebook-cell-{execution_count}", "eval"),
                            namespace,
                        )
                    else:
                        exec(compile(parsed, f"notebook-cell-{execution_count}", "exec"), namespace)

                stdout_text = stdout_buffer.getvalue()
                stderr_text = stderr_buffer.getvalue()
                if stdout_text:
                    cell.outputs.append(
                        nbf.v4.new_output(output_type="stream", name="stdout", text=stdout_text)
                    )
                if stderr_text:
                    cell.outputs.append(
                        nbf.v4.new_output(output_type="stream", name="stderr", text=stderr_text)
                    )
                cell.outputs.extend(figure_outputs)
                if final_value is not None:
                    cell.outputs.append(
                        nbf.v4.new_output(
                            output_type="execute_result",
                            execution_count=execution_count,
                            data=_result_data(final_value),
                            metadata={},
                        )
                    )
            except Exception as exc:
                cell.outputs.append(
                    nbf.v4.new_output(
                        output_type="error",
                        ename=type(exc).__name__,
                        evalue=str(exc),
                        traceback=[f"{type(exc).__name__}: {exc}"],
                    )
                )
                raise
    finally:
        os.chdir(original_directory)


def main() -> None:
    NOTEBOOK_PATH.parent.mkdir(parents=True, exist_ok=True)
    notebook = build_notebook()
    execute_in_process(notebook)
    nbf.write(notebook, NOTEBOOK_PATH)
    print(f"Built and executed {NOTEBOOK_PATH}")


if __name__ == "__main__":
    main()
