"""Flask healthcare income and spending survey application."""

from __future__ import annotations

import logging
import os
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping

from flask import Flask, current_app, jsonify, render_template, request
from flask_wtf.csrf import CSRFProtect
from pymongo import MongoClient
from pymongo.errors import PyMongoError

from models import EXPENSE_CATEGORIES, User


csrf = CSRFProtect()

GENDER_OPTIONS = (
    "Female",
    "Male",
    "Non-binary",
    "Prefer not to say",
)

CATEGORY_LABELS = {
    "utilities": "Utilities",
    "entertainment": "Entertainment",
    "school_fees": "School fees",
    "shopping": "Shopping",
    "healthcare": "Healthcare",
}


def create_app(test_config: Mapping[str, Any] | None = None) -> Flask:
    """Create and configure the Flask application."""

    default_secret = "development-only-change-me"
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=os.getenv("SECRET_KEY", default_secret),
        MONGO_URI=os.getenv("MONGO_URI", "mongodb://localhost:27017/"),
        MONGO_DB_NAME=os.getenv("MONGO_DB_NAME", "healthcare_survey"),
        MONGO_COLLECTION=os.getenv("MONGO_COLLECTION", "participants"),
        MAX_CONTENT_LENGTH=32 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("FLASK_ENV") == "production",
    )
    if test_config:
        app.config.update(test_config)

    if os.getenv("FLASK_ENV") == "production" and app.config["SECRET_KEY"] == default_secret:
        raise RuntimeError("SECRET_KEY must be configured before production deployment.")

    csrf.init_app(app)
    app.logger.setLevel(logging.INFO)

    @app.after_request
    def add_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; style-src 'self'; script-src 'self'; "
            "img-src 'self' data:; form-action 'self'; frame-ancestors 'self'",
        )
        return response

    @app.route("/", methods=["GET", "POST"])
    def survey():
        errors: list[str] = []
        if request.method == "POST":
            user, errors = parse_submission(request.form)
            if not errors and user is not None:
                try:
                    result = get_collection().insert_one(user.to_document())
                    return render_template(
                        "success.html",
                        reference=str(result.inserted_id),
                    )
                except PyMongoError:
                    current_app.logger.exception("Survey submission could not be saved")
                    errors.append(
                        "The survey could not be saved at this time. Please try again shortly."
                    )

        return render_template(
            "index.html",
            errors=errors,
            form_data=request.form,
            categories=CATEGORY_LABELS,
            gender_options=GENDER_OPTIONS,
        )

    @app.get("/health")
    @csrf.exempt
    def health():
        try:
            get_mongo_client().admin.command("ping")
            return jsonify(status="healthy", database="connected"), 200
        except PyMongoError:
            return jsonify(status="degraded", database="unavailable"), 503

    @app.errorhandler(413)
    def request_too_large(_error):
        return render_template(
            "index.html",
            errors=["The submitted form was larger than the allowed limit."],
            form_data={},
            categories=CATEGORY_LABELS,
            gender_options=GENDER_OPTIONS,
        ), 413

    return app


def get_mongo_client() -> MongoClient:
    """Return one reusable MongoDB client for the current process."""

    configured_client = current_app.config.get("MONGO_CLIENT")
    if configured_client is not None:
        return configured_client

    client = current_app.extensions.get("mongo_client")
    if client is None:
        client = MongoClient(
            current_app.config["MONGO_URI"],
            serverSelectionTimeoutMS=5_000,
            connectTimeoutMS=5_000,
        )
        current_app.extensions["mongo_client"] = client
    return client


def get_collection():
    """Return the configured participant collection."""

    database = get_mongo_client()[current_app.config["MONGO_DB_NAME"]]
    return database[current_app.config["MONGO_COLLECTION"]]


def parse_submission(form: Mapping[str, str]) -> tuple[User | None, list[str]]:
    """Validate a submitted form and return a ``User`` when valid."""

    errors: list[str] = []

    age: int | None = None
    try:
        age = int(str(form.get("age", "")).strip())
        if not 1 <= age <= 120:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("Age must be a whole number between 1 and 120.")

    gender = str(form.get("gender", "")).strip()
    if gender not in GENDER_OPTIONS:
        errors.append("Please select a valid gender option.")

    total_income = parse_money(
        form.get("total_income", ""),
        "Total income",
        errors,
        allow_zero=False,
    )

    selected_categories = [
        category
        for category in EXPENSE_CATEGORIES
        if str(form.get(f"{category}_selected", "")) == "on"
    ]
    if not selected_categories:
        errors.append("Please select at least one expense category.")

    expenses: dict[str, float] = {}
    for category in EXPENSE_CATEGORIES:
        if category in selected_categories:
            amount = parse_money(
                form.get(f"{category}_amount", ""),
                CATEGORY_LABELS[category],
                errors,
                allow_zero=False,
            )
            expenses[category] = amount if amount is not None else 0.0
        else:
            expenses[category] = 0.0

    if errors or age is None or total_income is None:
        return None, errors

    return User(
        age=age,
        gender=gender,
        total_income=total_income,
        expenses=expenses,
    ), []


def parse_money(
    raw_value: object,
    label: str,
    errors: list[str],
    *,
    allow_zero: bool,
) -> float | None:
    """Parse and validate a monetary form value."""

    try:
        value = Decimal(str(raw_value).strip())
        if not value.is_finite() or value < 0 or value > Decimal("1000000000"):
            raise InvalidOperation
        if not allow_zero and value == 0:
            raise InvalidOperation
        return float(value.quantize(Decimal("0.01")))
    except (InvalidOperation, ValueError):
        qualifier = "a positive" if not allow_zero else "a non-negative"
        errors.append(f"{label} must be {qualifier} amount not exceeding 1 billion.")
        return None


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
