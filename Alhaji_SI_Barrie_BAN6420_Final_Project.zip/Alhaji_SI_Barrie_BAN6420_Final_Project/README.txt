# Flask Healthcare Income and Spending Survey

**Student:** Alhaji Sorie Ibrahim Barrie  
**Course:** BAN6420 - R and Python  
**Assignment:** Final Project - Flask Healthcare Application

## Project overview

I developed this application as a survey tool for collecting participants' age,
gender, total income, and expenses in preparation for a healthcare product
launch. The responsive Flask webpage uses a checkbox and corresponding amount
field for each required expense category: utilities, entertainment, school
fees, shopping, and healthcare.

Each validated response is stored in MongoDB. My Python `User` class provides a
consistent structure for the web, database, and export stages. The export script
loops through MongoDB records and creates a CSV file. The executed Jupyter
notebook loads that CSV, identifies the ages with the highest average income,
compares spending categories across gender groups, and exports two 300-DPI PNG
charts for client use in PowerPoint.

The included demonstration CSV is synthetic and contains no real participant
information.

## How the assignment requirements are addressed

| Requirement | Implementation |
| --- | --- |
| Flask data-collection webpage | `app.py`, `templates/`, and `static/` |
| Age, gender, income, and expenses | Validated fields on the main survey form |
| Expense checkboxes and amount textboxes | Five paired controls in `templates/index.html` |
| MongoDB storage | PyMongo connection and nested `expenses` document in `app.py` |
| Python class named `User` | `models.py` |
| Loop through records and save CSV | `export_data.py` |
| Load CSV in Jupyter | `notebook/Healthcare_Spending_Analysis.ipynb` |
| Ages with highest income | `charts/01_ages_highest_income.png` |
| Gender across spending categories | `charts/02_gender_spending_categories.png` |
| AWS deployment readiness | `application.py`, `Procfile`, `.ebextensions/`, and `AWS_DEPLOYMENT.md` |
| Detailed documentation | This README and `AWS_DEPLOYMENT.md` |

## Main submission files

- `app.py` - Flask application factory, routes, validation, and MongoDB access.
- `models.py` - the required `User` class and CSV field definitions.
- `export_data.py` - loops through MongoDB records and exports them to CSV.
- `seed_sample_data.py` - generates reproducible synthetic demonstration data.
- `data/healthcare_survey_sample.csv` - included synthetic CSV export.
- `notebook/Healthcare_Spending_Analysis.ipynb` - fully executed analysis.
- `charts/` - both high-resolution figures for PowerPoint.
- `tests/` - automated checks for the form, model, database shape, and export.
- `AWS_DEPLOYMENT.md` - my AWS deployment design and readiness record.

## Fastest local setup: Docker

Docker Compose starts both the Flask application and MongoDB.

```bash
docker compose up --build
```

Open `http://localhost:5000` in a browser. Stop the application with
`Ctrl+C`, followed by:

```bash
docker compose down
```

MongoDB data are retained in the named Docker volume. Use
`docker compose down -v` only when the stored survey responses are no longer
needed.

## Standard Python setup

Python 3.10 or later and MongoDB are required.

### 1. Create and activate a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS or Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install the packages

For the complete application, analysis, and test environment:

```bash
python -m pip install -r requirements-dev.txt
```

For only the deployed Flask application:

```bash
python -m pip install -r requirements.txt
```

### 3. Configure the environment

Copy `.env.example` to `.env`, then replace the example secret key and MongoDB
connection string when necessary. The application defaults to a local MongoDB
server at `mongodb://localhost:27017/`.

Generate a development secret key with:

```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

Never commit `.env` or a live MongoDB password to a repository.

### 4. Start MongoDB and the Flask application

Start a local MongoDB service, then run:

```bash
flask --app app:create_app run --debug
```

Open `http://127.0.0.1:5000`. Every valid survey submission is inserted into:

- Database: `healthcare_survey`
- Collection: `participants`

These names can be changed through `MONGO_DB_NAME` and `MONGO_COLLECTION`.

## Export MongoDB records to CSV

After collecting responses, I export the records with:

```bash
python export_data.py --output data/healthcare_survey.csv
```

The script loops through all records in chronological order, creates a `User`
object from each MongoDB document, flattens the five expense fields, and writes
the result to CSV.

To insert the included synthetic demonstration records into a running MongoDB
database, use:

```bash
python seed_sample_data.py --insert-mongo
```

Running `seed_sample_data.py` without `--insert-mongo` only recreates the sample
CSV and does not change the database.

## Run the Jupyter analysis

Start Jupyter from the project folder:

```bash
jupyter lab
```

Open `notebook/Healthcare_Spending_Analysis.ipynb` and select **Run All**. The
notebook uses `data/healthcare_survey.csv` when a live export exists; otherwise,
it uses the included `data/healthcare_survey_sample.csv`. It performs data
quality checks, descriptive analysis, both required visualizations, and exports
the following presentation-ready files:

- `charts/01_ages_highest_income.png`
- `charts/02_gender_spending_categories.png`

The submitted notebook has already been executed and includes its tables,
findings, and chart outputs.

## Run the automated tests

```bash
pytest -q
```

The tests use an in-memory fake collection, so they do not alter a live MongoDB
database.

## AWS deployment preparation and current status

I designed and prepared the application for deployment on AWS Elastic
Beanstalk. The project includes all the files required for deployment:
`application.py` exposes the WSGI object, `requirements.txt` lists the
production dependencies, `Procfile` starts Gunicorn, `.ebextensions/`
identifies the WSGI entry point, and `.ebignore` keeps analysis-only files out
of the cloud source bundle. I also designed the production database connection
for MongoDB Atlas through securely configured environment variables.

A live AWS environment could not be provisioned before submission because the
development environment available for this assignment did not provide access
to an authorised AWS account or AWS credentials with permission to create
Elastic Beanstalk, EC2, S3, networking, and related resources. These resources
can incur continuing charges, and I considered it inappropriate to create
billable cloud infrastructure without the account holder's or institution's
explicit authorisation. This limitation relates only to external cloud-account
provisioning; it does not affect the completeness or deployability of the
application itself.

To demonstrate deployment readiness, I provided the tested AWS entry point,
Gunicorn process configuration, production dependency file, environment
configuration, database health endpoint, security controls, and a complete
deployment and verification record in `AWS_DEPLOYMENT.md`. The application can
therefore be deployed from any authorised AWS account without changing its
core source code once the account-specific credentials, region, MongoDB Atlas
URI, and runtime secret have been supplied.

## Security and data limitations

- The server validates all numeric inputs and permitted gender values.
- CSRF protection, content-length limits, secure cookie settings, and basic
  security headers are enabled.
- Database errors are logged without displaying internal details to users.
- Credentials are read from environment variables and excluded from Git.
- The demonstration dataset is synthetic; its findings are examples of the
  workflow and should not guide a real healthcare product launch.
- A production study would also require an approved privacy notice, informed
  consent, retention rules, access controls, and any applicable ethics review.

## Project structure

```text
Healthcare_Survey_Final_Project/
|-- .ebextensions/
|-- charts/
|-- data/
|-- notebook/
|-- scripts/
|-- static/
|-- templates/
|-- tests/
|-- app.py
|-- application.py
|-- export_data.py
|-- models.py
|-- seed_sample_data.py
|-- Dockerfile
|-- docker-compose.yml
|-- Procfile
|-- requirements.txt
|-- requirements-analysis.txt
|-- requirements-dev.txt
|-- AWS_DEPLOYMENT.md
`-- README.md
```
