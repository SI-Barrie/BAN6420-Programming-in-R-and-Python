"use strict";

document.querySelectorAll("[data-expense-row]").forEach((row) => {
    const checkbox = row.querySelector("[data-expense-checkbox]");
    const amount = row.querySelector("[data-expense-amount]");

    const updateAmountState = () => {
        amount.disabled = !checkbox.checked;
        amount.required = checkbox.checked;
        row.classList.toggle("is-selected", checkbox.checked);

        if (!checkbox.checked) {
            amount.value = "";
        } else {
            amount.focus();
        }
    };

    checkbox.addEventListener("change", updateAmountState);
    row.classList.toggle("is-selected", checkbox.checked);
    amount.required = checkbox.checked;
});
