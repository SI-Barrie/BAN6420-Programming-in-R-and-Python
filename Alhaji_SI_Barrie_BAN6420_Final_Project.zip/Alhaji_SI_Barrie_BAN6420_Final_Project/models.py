"""Domain model used by the survey application and CSV export workflow."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping


EXPENSE_CATEGORIES = (
    "utilities",
    "entertainment",
    "school_fees",
    "shopping",
    "healthcare",
)

CSV_FIELDS = (
    "age",
    "gender",
    "total_income",
    *EXPENSE_CATEGORIES,
    "total_expenses",
    "created_at",
)


@dataclass(slots=True)
class User:
    """A single healthcare survey participant.

    The class is intentionally independent of Flask and MongoDB so the same
    validation-friendly structure can be reused during collection, export, and
    analysis.
    """

    age: int
    gender: str
    total_income: float
    expenses: dict[str, float]
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        self.age = int(self.age)
        self.total_income = round(float(self.total_income), 2)
        self.expenses = {
            category: round(float(self.expenses.get(category, 0.0)), 2)
            for category in EXPENSE_CATEGORIES
        }

    @property
    def total_expenses(self) -> float:
        """Return the participant's total reported expenses."""

        return round(sum(self.expenses.values()), 2)

    def to_document(self) -> dict[str, Any]:
        """Convert the participant to a MongoDB-ready document."""

        return {
            "age": self.age,
            "gender": self.gender,
            "total_income": self.total_income,
            "expenses": dict(self.expenses),
            "total_expenses": self.total_expenses,
            "created_at": self.created_at,
        }

    @classmethod
    def from_document(cls, document: Mapping[str, Any]) -> "User":
        """Create a participant from a MongoDB document."""

        created_at = document.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        if not isinstance(created_at, datetime):
            created_at = datetime.now(timezone.utc)

        return cls(
            age=int(document["age"]),
            gender=str(document["gender"]),
            total_income=float(document["total_income"]),
            expenses=dict(document.get("expenses", {})),
            created_at=created_at,
        )

    def to_csv_row(self) -> dict[str, int | float | str]:
        """Return a flat row suitable for ``csv.DictWriter``."""

        created_at = self.created_at
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)

        return {
            "age": self.age,
            "gender": self.gender,
            "total_income": self.total_income,
            **self.expenses,
            "total_expenses": self.total_expenses,
            "created_at": created_at.isoformat(),
        }
