"""Export MongoDB survey records to a flat CSV file."""

from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path
from typing import Any, Iterable, Mapping

from pymongo import MongoClient

from models import CSV_FIELDS, User


def export_documents(
    documents: Iterable[Mapping[str, Any]],
    output_path: str | Path,
) -> int:
    """Loop through survey documents and write them to a CSV file."""

    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)

    count = 0
    with destination.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for document in documents:
            writer.writerow(User.from_document(document).to_csv_row())
            count += 1
    return count


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Export healthcare survey participants from MongoDB to CSV."
    )
    parser.add_argument(
        "--output",
        default="data/healthcare_survey.csv",
        help="Destination CSV path (default: data/healthcare_survey.csv)",
    )
    parser.add_argument("--mongo-uri", default=os.getenv("MONGO_URI", "mongodb://localhost:27017/"))
    parser.add_argument("--database", default=os.getenv("MONGO_DB_NAME", "healthcare_survey"))
    parser.add_argument("--collection", default=os.getenv("MONGO_COLLECTION", "participants"))
    args = parser.parse_args()

    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=5_000)
    try:
        documents = client[args.database][args.collection].find({}).sort("created_at", 1)
        count = export_documents(documents, args.output)
    finally:
        client.close()

    print(f"Exported {count} survey record(s) to {args.output}")


if __name__ == "__main__":
    main()
