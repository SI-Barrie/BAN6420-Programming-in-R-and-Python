"""Create a deterministic synthetic dataset for demonstration and grading."""

from __future__ import annotations

import argparse
import os
import random
from datetime import datetime, timedelta, timezone

from pymongo import MongoClient

from export_data import export_documents
from models import User


def generate_sample_users(count: int = 80, seed: int = 6420) -> list[User]:
    """Return synthetic participants without using real personal information."""

    rng = random.Random(seed)
    ages = [22, 25, 28, 31, 34, 37, 40, 43, 46, 49, 52, 55, 58, 61, 64, 67]
    genders = ["Female", "Male", "Non-binary", "Prefer not to say"]
    gender_weights = [0.42, 0.42, 0.08, 0.08]
    start = datetime(2026, 5, 1, 9, 0, tzinfo=timezone.utc)

    users: list[User] = []
    for index in range(count):
        age = ages[index % len(ages)]
        gender = rng.choices(genders, weights=gender_weights, k=1)[0]

        career_curve = max(0, 1_400 - abs(age - 52) * 45)
        total_income = max(
            18_000,
            rng.gauss(19_000 + age * 780 + career_curve * 8, 8_500),
        )

        utilities = max(1_200, rng.gauss(total_income * 0.075, 650))
        entertainment = max(0, rng.gauss(total_income * 0.035, 500))
        school_fees = (
            max(0, rng.gauss(total_income * 0.065, 1_100))
            if 28 <= age <= 58 and rng.random() < 0.68
            else 0
        )
        shopping = max(0, rng.gauss(total_income * 0.055, 700))
        healthcare = max(250, rng.gauss(350 + age * 31, 320))

        users.append(
            User(
                age=age,
                gender=gender,
                total_income=round(total_income, 2),
                expenses={
                    "utilities": round(utilities, 2),
                    "entertainment": round(entertainment, 2),
                    "school_fees": round(school_fees, 2),
                    "shopping": round(shopping, 2),
                    "healthcare": round(healthcare, 2),
                },
                created_at=start + timedelta(hours=index * 7),
            )
        )
    return users


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate synthetic healthcare survey data.")
    parser.add_argument("--count", type=int, default=80)
    parser.add_argument("--seed", type=int, default=6420)
    parser.add_argument("--output", default="data/healthcare_survey_sample.csv")
    parser.add_argument(
        "--insert-mongo",
        action="store_true",
        help="Also insert the synthetic records into the configured MongoDB collection.",
    )
    parser.add_argument("--mongo-uri", default=os.getenv("MONGO_URI", "mongodb://localhost:27017/"))
    parser.add_argument("--database", default=os.getenv("MONGO_DB_NAME", "healthcare_survey"))
    parser.add_argument("--collection", default=os.getenv("MONGO_COLLECTION", "participants"))
    args = parser.parse_args()

    users = generate_sample_users(args.count, args.seed)
    documents = [user.to_document() for user in users]
    exported = export_documents(documents, args.output)
    print(f"Created {exported} synthetic record(s) in {args.output}")

    if args.insert_mongo:
        client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=5_000)
        try:
            for document in documents:
                document["is_synthetic"] = True
            result = client[args.database][args.collection].insert_many(documents)
        finally:
            client.close()
        print(f"Inserted {len(result.inserted_ids)} synthetic record(s) into MongoDB")


if __name__ == "__main__":
    main()
