# Final Project Submission Checklist

- [x] Flask survey webpage created.
- [x] Age, gender, total income, and expenses collected.
- [x] Utilities, entertainment, school fees, shopping, and healthcare each use
      a checkbox with a corresponding amount input.
- [x] MongoDB integration implemented with PyMongo.
- [x] Python class named `User` created.
- [x] MongoDB records looped through and written to CSV.
- [x] CSV loaded and checked in the Jupyter notebook.
- [x] Ages with the highest average income visualized.
- [x] Gender spending across categories visualized.
- [x] Both charts exported as 300-DPI PNG files for PowerPoint.
- [x] Jupyter notebook executed with no error outputs.
- [x] AWS Elastic Beanstalk entry point and deployment configuration included.
- [x] AWS account-access limitation transparently documented.
- [x] Detailed local, analysis, test, and first-person AWS deployment record included.
- [x] Synthetic demonstration dataset clearly identified.
- [x] Automated tests included.
- [x] Submission packaged as a ZIP file.

## Before uploading to the learning platform

1. Review the AWS deployment-status explanation in `README.md` and the
   first-person deployment design in `AWS_DEPLOYMENT.md`.
2. Open the ZIP once to confirm `README.md` is at the top level.
3. Upload the ZIP as the final project submission.
