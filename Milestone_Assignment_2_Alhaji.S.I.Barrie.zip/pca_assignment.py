"""
Milestone Assignment 2: Principal Component Analysis
Student: Alhaji Sorie Ibrahim Barrie

This script:
1. Loads the cancer dataset available in sklearn.datasets using
   load_breast_cancer().
2. Standardizes the features.
3. Reduces the dataset to two principal components.
4. Identifies variables with the strongest absolute loadings.
5. Implements Logistic Regression as the optional bonus task.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def main() -> None:
    """Run the PCA and Logistic Regression workflow."""
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)

    cancer = load_breast_cancer()
    features = pd.DataFrame(cancer.data, columns=cancer.feature_names)
    target = pd.Series(cancer.target, name="target")

    print("Dataset shape:", features.shape)
    print("Target classes:", list(cancer.target_names))

    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)

    pca = PCA(n_components=2)
    principal_components = pca.fit_transform(scaled_features)

    pca_data = pd.DataFrame(
        principal_components,
        columns=["PC1", "PC2"],
    )
    pca_data["target"] = target
    pca_data["diagnosis"] = pca_data["target"].map(
        {index: name for index, name in enumerate(cancer.target_names)}
    )
    pca_data.to_csv(output_dir / "pca_two_components.csv", index=False)

    explained_variance = pca.explained_variance_ratio_
    print("\nExplained variance ratio:")
    print(f"PC1: {explained_variance[0]:.4f}")
    print(f"PC2: {explained_variance[1]:.4f}")
    print(f"Total: {explained_variance.sum():.4f}")

    loadings = pd.DataFrame(
        pca.components_.T,
        columns=["PC1", "PC2"],
        index=features.columns,
    )
    loadings["PC1_absolute"] = loadings["PC1"].abs()
    loadings["PC2_absolute"] = loadings["PC2"].abs()
    loadings.to_csv(output_dir / "pca_loadings.csv")

    print("\nTen strongest variables for PC1:")
    print(loadings.nlargest(10, "PC1_absolute")[["PC1"]])

    print("\nTen strongest variables for PC2:")
    print(loadings.nlargest(10, "PC2_absolute")[["PC2"]])

    # PCA scatter plot
    plt.figure(figsize=(8, 6))
    for target_value, target_name in enumerate(cancer.target_names):
        mask = target.to_numpy() == target_value
        plt.scatter(
            principal_components[mask, 0],
            principal_components[mask, 1],
            alpha=0.65,
            label=target_name,
        )
    plt.xlabel(f"PC1 ({explained_variance[0] * 100:.2f}% variance)")
    plt.ylabel(f"PC2 ({explained_variance[1] * 100:.2f}% variance)")
    plt.title("Cancer Dataset Reduced to Two Principal Components")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "pca_scatter_plot.png", dpi=200)
    plt.close()

    # Scree plot
    full_pca = PCA()
    full_pca.fit(scaled_features)
    cumulative_variance = np.cumsum(full_pca.explained_variance_ratio_)

    plt.figure(figsize=(8, 5))
    plt.plot(
        range(1, len(cumulative_variance) + 1),
        cumulative_variance,
        marker="o",
    )
    plt.axhline(y=0.90, linestyle="--")
    plt.xlabel("Number of Principal Components")
    plt.ylabel("Cumulative Explained Variance")
    plt.title("Scree Plot: Cumulative Explained Variance")
    plt.tight_layout()
    plt.savefig(output_dir / "scree_plot.png", dpi=200)
    plt.close()

    # Bonus: Logistic Regression
    x_train, x_test, y_train, y_test = train_test_split(
        principal_components,
        target,
        test_size=0.20,
        random_state=42,
        stratify=target,
    )

    classifier = LogisticRegression(random_state=42, max_iter=1000)
    classifier.fit(x_train, y_train)
    predictions = classifier.predict(x_test)

    print("\nBonus Logistic Regression Results")
    print(f"Accuracy: {accuracy_score(y_test, predictions):.4f}")
    print(f"Precision: {precision_score(y_test, predictions, average='weighted'):.4f}")
    print(f"Recall: {recall_score(y_test, predictions, average='weighted'):.4f}")
    print(f"F1-score: {f1_score(y_test, predictions, average='weighted'):.4f}")
    print("\nClassification report:")
    print(
        classification_report(
            y_test,
            predictions,
            target_names=cancer.target_names,
            digits=4,
        )
    )

    matrix = confusion_matrix(y_test, predictions)
    pd.DataFrame(
        matrix,
        index=[f"Actual_{name}" for name in cancer.target_names],
        columns=[f"Predicted_{name}" for name in cancer.target_names],
    ).to_csv(output_dir / "confusion_matrix.csv")

    plt.figure(figsize=(6, 5))
    plt.imshow(matrix)
    plt.title("Logistic Regression Confusion Matrix")
    plt.xlabel("Predicted Class")
    plt.ylabel("Actual Class")
    plt.xticks([0, 1], cancer.target_names)
    plt.yticks([0, 1], cancer.target_names)
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            plt.text(
                column,
                row,
                str(matrix[row, column]),
                ha="center",
                va="center",
            )
    plt.tight_layout()
    plt.savefig(output_dir / "confusion_matrix.png", dpi=200)
    plt.close()


if __name__ == "__main__":
    main()
