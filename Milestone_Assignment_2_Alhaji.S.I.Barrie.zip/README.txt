Student: Alhaji Sorie Ibrahim Barrie
Student ID: 267588
Course: BAN6420 - Programming in R & Python
Assignment: Milestone Assignment 2 - Principal Component Analysis
Submission Date: August 04, 2026

Project Overview

This project implements Principal Component Analysis (PCA) using the
cancer dataset available in 'sklearn.datasets', accessed through the
load_breast_cancer() function.

The project fulfils all required tasks:

1.  Implements PCA on the cancer dataset.
2.  Standardizes the variables before PCA.
3.  Reduces the original 30-feature dataset to two principal components.
4.  Identifies variables with the strongest PCA loadings.
5.  Implements the optional Logistic Regression prediction task.
6.  Produces a PCA scatter plot, scree plot, confusion matrix, and
    output files.

Dataset

The dataset contains 569 observations and 30 numerical predictor
variables. The target variable contains two diagnostic classes:
malignant and benign.

Main Results

-   PC1 explained variance: 44.27%
-   PC2 explained variance: 18.97%
-   Total variance explained by two components: 63.24%
-   Logistic Regression test accuracy: 94.74%
-   Weighted precision: 94.85%
-   Weighted recall: 94.74%
-   Weighted F1-score: 94.76%

Project Files

-   Milestone_Assignment_2_PCA.ipynb – Jupyter Notebook.
-   pca_assignment.py – Python script.
-   README.txt – Project documentation.
-   outputs – Generated charts and result files.

Requirements

Required libraries:
-   jupyter
-   matplotlib
-   numpy
-   pandas
-   scikit-learn
-   python-docx

Running the Project

Jupyter Notebook

Open and run Milestone_Assignment_2_PCA.ipynb.

Python Script

    python pca_assignment.py

Project Outputs

Running the project generates: - PCA-transformed dataset (2 principal
components) - PCA loadings - Scree plot - PCA scatter plot - Confusion
matrix - Logistic Regression evaluation metrics

Methodology

1.  Load the cancer dataset from sklearn.datasets.
2.  Standardize the predictor variables using StandardScaler.
3.  Apply PCA and retain two principal components.
4.  Examine explained variance and component loadings.
5.  Visualize the reduced dataset.
6.  Train and evaluate a Logistic Regression model.

Interpretation Note

PCA transforms the original variables into principal components that
capture the dominant patterns in the dataset. Variables with larger
absolute loadings contribute more strongly to each component. PCA does
not establish causal relationships or determine donor funding decisions.
