# Train and evaluate a six-layer CNN on Fashion MNIST using R and Keras.
# The full workflow is encapsulated in an R6 class as required by the assignment.

suppressPackageStartupMessages({
  library(keras3)
  library(R6)
})


FashionMNISTCNN <- R6Class(
  "FashionMNISTCNN",
  public = list(
    class_names = c(
      "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
      "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
    ),
    epochs = NULL,
    batch_size = NULL,
    seed = NULL,
    output_dir = NULL,
    train_limit = NULL,
    model = NULL,
    history = NULL,
    x_train = NULL,
    y_train = NULL,
    x_test = NULL,
    y_test = NULL,

    initialize = function(
      epochs = 5L,
      batch_size = 128L,
      seed = 42L,
      output_dir = "outputs",
      train_limit = NULL
    ) {
      if (epochs < 1L) stop("epochs must be at least 1")
      if (batch_size < 1L) stop("batch_size must be at least 1")
      if (!is.null(train_limit) && train_limit < 100L) {
        stop("train_limit must be at least 100 when specified")
      }

      self$epochs <- as.integer(epochs)
      self$batch_size <- as.integer(batch_size)
      self$seed <- as.integer(seed)
      self$output_dir <- output_dir
      self$train_limit <- if (is.null(train_limit)) NULL else as.integer(train_limit)

      dir.create(self$output_dir, recursive = TRUE, showWarnings = FALSE)
      set_random_seed(self$seed)
    },

    load_and_prepare_data = function() {
      data <- dataset_fashion_mnist()

      self$x_train <- data$train$x
      self$y_train <- data$train$y
      self$x_test <- data$test$x
      self$y_test <- data$test$y

      if (!is.null(self$train_limit)) {
        selected <- seq_len(self$train_limit)
        self$x_train <- self$x_train[selected, , , drop = FALSE]
        self$y_train <- self$y_train[selected]
      }

      storage.mode(self$x_train) <- "double"
      storage.mode(self$x_test) <- "double"
      self$x_train <- self$x_train / 255
      self$x_test <- self$x_test / 255

      dim(self$x_train) <- c(dim(self$x_train), 1L)
      dim(self$x_test) <- c(dim(self$x_test), 1L)

      cat("Training images:", paste(dim(self$x_train), collapse = " x "), "\n")
      cat("Test images:    ", paste(dim(self$x_test), collapse = " x "), "\n")
    },

    build_model = function() {
      # The input shape is metadata rather than a processing layer. The model
      # therefore contains exactly the six layers listed below.
      self$model <- keras_model_sequential(
        input_shape = c(28L, 28L, 1L),
        name = "fashion_mnist_six_layer_cnn"
      ) |>
        layer_conv_2d(
          filters = 32L,
          kernel_size = c(3L, 3L),
          activation = "relu",
          name = "conv_1"
        ) |>
        layer_max_pooling_2d(
          pool_size = c(2L, 2L),
          name = "pool_1"
        ) |>
        layer_conv_2d(
          filters = 64L,
          kernel_size = c(3L, 3L),
          activation = "relu",
          name = "conv_2"
        ) |>
        layer_max_pooling_2d(
          pool_size = c(2L, 2L),
          name = "pool_2"
        ) |>
        layer_flatten(name = "flatten") |>
        layer_dense(
          units = 10L,
          activation = "softmax",
          name = "output"
        )

      if (length(self$model$layers) != 6L) {
        stop(
          sprintf(
            "The model must contain exactly six layers; found %d.",
            length(self$model$layers)
          )
        )
      }

      self$model |> compile(
        optimizer = "adam",
        loss = "sparse_categorical_crossentropy",
        metrics = "accuracy"
      )
      summary(self$model)
    },

    train = function() {
      private$require_data()
      private$require_model()

      self$history <- self$model |> fit(
        x = self$x_train,
        y = self$y_train,
        epochs = self$epochs,
        batch_size = self$batch_size,
        validation_split = 0.10,
        shuffle = TRUE,
        verbose = 2
      )
    },

    evaluate_model = function() {
      private$require_data()
      private$require_model()

      result <- self$model |> evaluate(
        x = self$x_test,
        y = self$y_test,
        verbose = 0
      )
      result <- as.numeric(result)
      metrics <- list(test_loss = result[[1]], test_accuracy = result[[2]])

      cat(sprintf("Test loss:     %.4f\n", metrics$test_loss))
      cat(sprintf("Test accuracy: %.4f\n", metrics$test_accuracy))
      metrics
    },

    predict_images = function(indices = c(1L, 2L)) {
      private$require_data()
      private$require_model()

      indices <- as.integer(indices)
      if (length(indices) < 2L) {
        stop("At least two test-image indices are required.")
      }
      if (any(indices < 1L) || any(indices > dim(self$x_test)[[1]])) {
        stop("Every R prediction index must be between 1 and 10,000.")
      }

      images <- self$x_test[indices, , , , drop = FALSE]
      probabilities <- self$model |> predict(images, verbose = 0)
      predicted_labels <- max.col(probabilities, ties.method = "first") - 1L
      actual_labels <- as.integer(self$y_test[indices])

      rows <- lapply(seq_along(indices), function(position) {
        predicted <- predicted_labels[[position]]
        actual <- actual_labels[[position]]
        confidence <- probabilities[position, predicted + 1L]

        cat(sprintf(
          paste0(
            "Image %4d: predicted=%-12s actual=%-12s confidence=%.2f%%\n"
          ),
          indices[[position]],
          self$class_names[[predicted + 1L]],
          self$class_names[[actual + 1L]],
          100 * confidence
        ))

        data.frame(
          image_index = indices[[position]],
          predicted_label = predicted,
          predicted_class = self$class_names[[predicted + 1L]],
          actual_label = actual,
          actual_class = self$class_names[[actual + 1L]],
          confidence = confidence,
          correct = predicted == actual,
          stringsAsFactors = FALSE
        )
      })

      prediction_table <- do.call(rbind, rows)
      write.csv(
        prediction_table,
        file.path(self$output_dir, "r_predictions.csv"),
        row.names = FALSE
      )
      private$plot_predictions(indices, prediction_table)
      invisible(prediction_table)
    },

    save_artifacts = function(metrics) {
      private$require_model()
      if (is.null(self$history)) {
        stop("Train the model before saving training artifacts.")
      }

      self$model |> save_model(
        file.path(self$output_dir, "r_fashion_mnist_cnn.keras"),
        overwrite = TRUE
      )

      writeLines(
        c(
          sprintf("Test loss: %.6f", metrics$test_loss),
          sprintf("Test accuracy: %.6f", metrics$test_accuracy)
        ),
        file.path(self$output_dir, "r_test_metrics.txt")
      )

      metric_data <- self$history$metrics
      history_table <- data.frame(
        epoch = seq_along(metric_data$loss),
        loss = as.numeric(metric_data$loss),
        accuracy = as.numeric(metric_data$accuracy),
        val_loss = as.numeric(metric_data$val_loss),
        val_accuracy = as.numeric(metric_data$val_accuracy)
      )
      write.csv(
        history_table,
        file.path(self$output_dir, "r_training_history.csv"),
        row.names = FALSE
      )
      private$plot_training_history(history_table)
      cat("\nArtifacts saved in:", normalizePath(self$output_dir), "\n")
    },

    run = function(prediction_indices = c(1L, 2L)) {
      self$load_and_prepare_data()
      self$build_model()
      self$train()
      metrics <- self$evaluate_model()
      self$predict_images(prediction_indices)
      self$save_artifacts(metrics)
      invisible(metrics)
    }
  ),

  private = list(
    require_data = function() {
      data_objects <- list(
        self$x_train, self$y_train, self$x_test, self$y_test
      )
      if (any(vapply(data_objects, is.null, logical(1)))) {
        stop("Load and prepare the data before this operation.")
      }
    },

    require_model = function() {
      if (is.null(self$model)) {
        stop("Build the model before this operation.")
      }
    },

    plot_predictions = function(indices, prediction_table) {
      file_path <- file.path(self$output_dir, "r_predictions.png")
      png(file_path, width = 1400, height = 650, res = 150)
      old_par <- par(
        mfrow = c(1, length(indices)),
        mar = c(1, 1, 4, 1),
        oma = c(0, 0, 2, 0)
      )

      for (position in seq_along(indices)) {
        image_matrix <- self$x_test[indices[[position]], , , 1L]
        displayed <- t(image_matrix[28:1, ])
        title_colour <- if (prediction_table$correct[[position]]) {
          "darkgreen"
        } else {
          "firebrick"
        }
        image(
          displayed,
          col = gray.colors(256L, start = 1, end = 0),
          axes = FALSE,
          main = sprintf(
            "Predicted: %s\nActual: %s\nConfidence: %.1f%%",
            prediction_table$predicted_class[[position]],
            prediction_table$actual_class[[position]],
            100 * prediction_table$confidence[[position]]
          ),
          col.main = title_colour,
          cex.main = 0.85
        )
      }
      mtext(
        "Fashion MNIST Predictions",
        side = 3,
        outer = TRUE,
        line = 0.5,
        font = 2,
        cex = 1.2
      )
      par(old_par)
      dev.off()
    },

    plot_training_history = function(history_table) {
      file_path <- file.path(self$output_dir, "r_training_history.png")
      png(file_path, width = 1500, height = 650, res = 150)
      old_par <- par(mfrow = c(1, 2), mar = c(4, 4, 3, 1))

      matplot(
        history_table$epoch,
        cbind(history_table$loss, history_table$val_loss),
        type = "o",
        pch = c(16, 17),
        lty = 1,
        col = c("#2E74B5", "#C55A11"),
        xlab = "Epoch",
        ylab = "Sparse cross-entropy",
        main = "Loss"
      )
      legend(
        "topright",
        legend = c("Training", "Validation"),
        col = c("#2E74B5", "#C55A11"),
        lty = 1,
        pch = c(16, 17),
        bty = "n"
      )
      grid()

      matplot(
        history_table$epoch,
        cbind(history_table$accuracy, history_table$val_accuracy),
        type = "o",
        pch = c(16, 17),
        lty = 1,
        col = c("#2E74B5", "#C55A11"),
        xlab = "Epoch",
        ylab = "Accuracy",
        main = "Accuracy"
      )
      legend(
        "bottomright",
        legend = c("Training", "Validation"),
        col = c("#2E74B5", "#C55A11"),
        lty = 1,
        pch = c(16, 17),
        bty = "n"
      )
      grid()

      par(old_par)
      dev.off()
    }
  )
)


# Environment variables make the script configurable while retaining simple
# defaults for the submitted assignment.
epochs <- as.integer(Sys.getenv("FASHION_EPOCHS", "5"))
batch_size <- as.integer(Sys.getenv("FASHION_BATCH_SIZE", "128"))
output_dir <- Sys.getenv("FASHION_OUTPUT_DIR", "outputs")
train_limit_text <- Sys.getenv("FASHION_TRAIN_LIMIT", "")
train_limit <- if (nzchar(train_limit_text)) as.integer(train_limit_text) else NULL

classifier <- FashionMNISTCNN$new(
  epochs = epochs,
  batch_size = batch_size,
  seed = 42L,
  output_dir = output_dir,
  train_limit = train_limit
)
classifier$run(prediction_indices = c(1L, 2L))
