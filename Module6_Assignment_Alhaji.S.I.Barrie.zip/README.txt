Student: Alhaji Sorie Ibrahim Barrie
Student ID: 267588
Course: BAN6420 - Programming in R & Python
Assignment: Module 6 Assignment - Fashion MNIST Classification
Submission Date: August 07, 2026

Project Overview

This project develops a six-layer Convolutional Neural Network (CNN) in
Python and R to classify images from the Fashion MNIST dataset. The
Python implementation uses a class with Keras, while the R implementation
uses an R6 class with the R interface to Keras.

The project fulfils the required tasks:

1.  Implements object-oriented CNN models in both Python and R.
2.  Loads and preprocesses the Fashion MNIST dataset.
3.  Builds a six-layer CNN for image classification.
4.  Trains and evaluates the models using test data.
5.  Predicts the classes of at least two test images.
6.  Produces model files, evaluation metrics, prediction tables, and
    visualisations.

Dataset

Fashion MNIST contains 60,000 training images and 10,000 test images.
Each observation is a 28 x 28 grayscale image belonging to one of ten
clothing classes: T-shirt/top, trouser, pullover, dress, coat, sandal,
shirt, sneaker, bag, and ankle boot.

The pixel values are converted from the original range of 0-255 to a
range of 0-1 before model training.

CNN Architecture

The model uses an input shape of 28 x 28 x 1 and the following six
processing layers:

1.  Convolutional layer: 32 filters, 3 x 3 kernel, and ReLU activation.
2.  Max-pooling layer: 2 x 2 pool size.
3.  Convolutional layer: 64 filters, 3 x 3 kernel, and ReLU activation.
4.  Max-pooling layer: 2 x 2 pool size.
5.  Flatten layer: converts the feature maps into a single vector.
6.  Dense output layer: 10 units with softmax activation.

The model uses the Adam optimiser, sparse categorical cross-entropy loss,
and classification accuracy. Ten percent of the training data is used
for validation.

Project Files

-   fashion_mnist_cnn.py - Python implementation.
-   fashion_mnist_cnn.R - R implementation.
-   install_packages.R - R package setup file.
-   requirements.txt - Python package requirements.
-   README.txt - Project documentation.
-   outputs - Generated models, metrics, tables, and figures.

Requirements

Python requirements are listed in requirements.txt. The R implementation
uses the keras3 and R6 packages. Python and R were already installed and
used for the previous course assignments.

Running the Project

Python Program

    python python/fashion_mnist_cnn.py

R Program

    Rscript r/fashion_mnist_cnn.R

By default, both programs train for five epochs using a batch size of
128 and predict two test images. Python uses zero-based image indices 0
and 1, while R uses one-based indices 1 and 2.

Project Outputs

Running the programs generates:

-   A saved CNN model and trained weights.
-   Test loss and classification accuracy.
-   Training and validation results by epoch.
-   Training-history plots for loss and accuracy.
-   Prediction tables showing actual and predicted classes.
-   Images displaying the actual and predicted labels.

Methodology

1.  Load the Fashion MNIST training and test datasets.
2.  Rescale the image pixel values from 0-255 to 0-1.
3.  Reshape the images for CNN processing.
4.  Construct and compile the six-layer CNN.
5.  Train the model and monitor validation performance.
6.  Evaluate the trained model using the test dataset.
7.  Predict two selected test images and save the results.

Interpretation Note

Test accuracy measures the proportion of the 10,000 test images that the
model classifies correctly. Test loss measures the model's average
classification error, with lower values indicating better performance.
The training-history plots compare training and validation performance
and help to identify possible underfitting or overfitting.

Minor differences may occur between the Python and R results because of
differences in software environments and numerical processing.
