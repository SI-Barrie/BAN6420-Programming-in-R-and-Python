"""Train and evaluate a six-layer CNN on the Fashion MNIST dataset.

This submission uses an object-oriented workflow so that data preparation,
model construction, training, evaluation, prediction, and artifact creation are
encapsulated in one reusable class.
"""

from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path
from typing import Sequence

os.environ.setdefault("KERAS_BACKEND", "tensorflow")

import keras
import matplotlib.pyplot as plt
import numpy as np
from keras import layers


class FashionMNISTCNN:
    """Object-oriented Fashion MNIST classifier built with Keras."""

    CLASS_NAMES = (
        "T-shirt/top",
        "Trouser",
        "Pullover",
        "Dress",
        "Coat",
        "Sandal",
        "Shirt",
        "Sneaker",
        "Bag",
        "Ankle boot",
    )

    def __init__(
        self,
        epochs: int = 5,
        batch_size: int = 128,
        seed: int = 42,
        output_dir: str | Path = "outputs",
        train_limit: int | None = None,
    ) -> None:
        if epochs < 1:
            raise ValueError("epochs must be at least 1")
        if batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        if train_limit is not None and train_limit < 100:
            raise ValueError("train_limit must be at least 100 when specified")

        self.epochs = epochs
        self.batch_size = batch_size
        self.seed = seed
        self.output_dir = Path(output_dir)
        self.train_limit = train_limit

        self.model: keras.Model | None = None
        self.history: keras.callbacks.History | None = None
        self.x_train: np.ndarray | None = None
        self.y_train: np.ndarray | None = None
        self.x_test: np.ndarray | None = None
        self.y_test: np.ndarray | None = None

        self.output_dir.mkdir(parents=True, exist_ok=True)
        keras.utils.set_random_seed(self.seed)

    def load_and_prepare_data(self) -> None:
        """Load Fashion MNIST, normalise pixels, and add the channel axis."""
        (x_train, y_train), (x_test, y_test) = (
            keras.datasets.fashion_mnist.load_data()
        )

        if self.train_limit is not None:
            x_train = x_train[: self.train_limit]
            y_train = y_train[: self.train_limit]

        self.x_train = np.expand_dims(x_train.astype("float32") / 255.0, axis=-1)
        self.x_test = np.expand_dims(x_test.astype("float32") / 255.0, axis=-1)
        self.y_train = y_train.astype("int64")
        self.y_test = y_test.astype("int64")

        print(f"Training images: {self.x_train.shape}")
        print(f"Test images:     {self.x_test.shape}")

    def build_model(self) -> None:
        """Build and compile the required six-layer CNN.

        The input specification is model metadata and is not counted as a
        processing layer. The six layers are two convolution layers, two
        pooling layers, one flatten layer, and one output layer.
        """
        self.model = keras.Sequential(
            [
                keras.Input(shape=(28, 28, 1), name="image_input"),
                layers.Conv2D(
                    32,
                    kernel_size=(3, 3),
                    activation="relu",
                    name="conv_1",
                ),
                layers.MaxPooling2D(pool_size=(2, 2), name="pool_1"),
                layers.Conv2D(
                    64,
                    kernel_size=(3, 3),
                    activation="relu",
                    name="conv_2",
                ),
                layers.MaxPooling2D(pool_size=(2, 2), name="pool_2"),
                layers.Flatten(name="flatten"),
                layers.Dense(10, activation="softmax", name="output"),
            ],
            name="fashion_mnist_six_layer_cnn",
        )

        if len(self.model.layers) != 6:
            raise RuntimeError(
                f"The model must contain exactly six layers; found "
                f"{len(self.model.layers)}."
            )

        self.model.compile(
            optimizer="adam",
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"],
        )
        self.model.summary()

    def train(self) -> None:
        """Train the CNN with a 10 percent validation split."""
        self._require_data()
        self._require_model()
        assert self.model is not None
        assert self.x_train is not None and self.y_train is not None

        self.history = self.model.fit(
            self.x_train,
            self.y_train,
            epochs=self.epochs,
            batch_size=self.batch_size,
            validation_split=0.10,
            shuffle=True,
            verbose=2,
        )

    def evaluate(self) -> tuple[float, float]:
        """Evaluate the trained model on the held-out test set."""
        self._require_data()
        self._require_model()
        assert self.model is not None
        assert self.x_test is not None and self.y_test is not None

        test_loss, test_accuracy = self.model.evaluate(
            self.x_test, self.y_test, verbose=0
        )
        print(f"Test loss:     {test_loss:.4f}")
        print(f"Test accuracy: {test_accuracy:.4f}")
        return float(test_loss), float(test_accuracy)

    def predict_images(
        self, indices: Sequence[int]
    ) -> tuple[np.ndarray, np.ndarray]:
        """Predict at least two selected test images and print the results."""
        self._require_data()
        self._require_model()
        if len(indices) < 2:
            raise ValueError("At least two test-image indices are required.")

        assert self.model is not None
        assert self.x_test is not None and self.y_test is not None

        clean_indices = np.asarray(indices, dtype=int)
        if np.any(clean_indices < 0) or np.any(clean_indices >= len(self.x_test)):
            raise IndexError("Every prediction index must be between 0 and 9,999.")

        probabilities = self.model.predict(
            self.x_test[clean_indices], verbose=0
        )
        predicted_labels = np.argmax(probabilities, axis=1)

        print("\nPredictions")
        print("-" * 72)
        for index, predicted, probability_vector in zip(
            clean_indices, predicted_labels, probabilities
        ):
            actual = int(self.y_test[index])
            confidence = float(probability_vector[predicted])
            print(
                f"Image {index:>4}: predicted={self.CLASS_NAMES[predicted]:<12} "
                f"actual={self.CLASS_NAMES[actual]:<12} "
                f"confidence={confidence:.2%}"
            )

        self._plot_predictions(clean_indices, predicted_labels, probabilities)
        self._write_prediction_csv(
            clean_indices, predicted_labels, probabilities
        )
        return predicted_labels, probabilities

    def save_artifacts(self, test_loss: float, test_accuracy: float) -> None:
        """Save the model, metrics, history data, and a learning-curve plot."""
        self._require_model()
        if self.history is None:
            raise RuntimeError("Train the model before saving training artifacts.")
        assert self.model is not None

        model_path = self.output_dir / "python_fashion_mnist_cnn.keras"
        self.model.save(model_path)

        metrics_path = self.output_dir / "python_test_metrics.txt"
        metrics_path.write_text(
            f"Test loss: {test_loss:.6f}\n"
            f"Test accuracy: {test_accuracy:.6f}\n",
            encoding="utf-8",
        )

        history_path = self.output_dir / "python_training_history.csv"
        metric_names = list(self.history.history.keys())
        epochs_recorded = len(self.history.history[metric_names[0]])
        with history_path.open("w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(["epoch", *metric_names])
            for row_index in range(epochs_recorded):
                writer.writerow(
                    [
                        row_index + 1,
                        *[
                            self.history.history[name][row_index]
                            for name in metric_names
                        ],
                    ]
                )

        self._plot_training_history()
        print(f"\nArtifacts saved in: {self.output_dir.resolve()}")

    def run(self, prediction_indices: Sequence[int]) -> None:
        """Execute the complete classification workflow."""
        self.load_and_prepare_data()
        self.build_model()
        self.train()
        test_loss, test_accuracy = self.evaluate()
        self.predict_images(prediction_indices)
        self.save_artifacts(test_loss, test_accuracy)

    def _plot_predictions(
        self,
        indices: np.ndarray,
        predicted_labels: np.ndarray,
        probabilities: np.ndarray,
    ) -> None:
        assert self.x_test is not None and self.y_test is not None
        figure, axes = plt.subplots(1, len(indices), figsize=(4 * len(indices), 4))
        axes_array = np.atleast_1d(axes)

        for axis, index, predicted, probability_vector in zip(
            axes_array, indices, predicted_labels, probabilities
        ):
            actual = int(self.y_test[index])
            confidence = float(probability_vector[predicted])
            title_colour = "darkgreen" if predicted == actual else "firebrick"
            axis.imshow(self.x_test[index].squeeze(), cmap="gray")
            axis.set_title(
                f"Predicted: {self.CLASS_NAMES[predicted]}\n"
                f"Actual: {self.CLASS_NAMES[actual]}\n"
                f"Confidence: {confidence:.1%}",
                color=title_colour,
                fontsize=10,
            )
            axis.axis("off")

        figure.suptitle("Fashion MNIST Predictions", fontsize=14, fontweight="bold")
        figure.tight_layout()
        figure.savefig(
            self.output_dir / "python_predictions.png",
            dpi=180,
            bbox_inches="tight",
        )
        plt.close(figure)

    def _write_prediction_csv(
        self,
        indices: np.ndarray,
        predicted_labels: np.ndarray,
        probabilities: np.ndarray,
    ) -> None:
        assert self.y_test is not None
        path = self.output_dir / "python_predictions.csv"
        with path.open("w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(
                [
                    "image_index",
                    "predicted_label",
                    "predicted_class",
                    "actual_label",
                    "actual_class",
                    "confidence",
                    "correct",
                ]
            )
            for index, predicted, probability_vector in zip(
                indices, predicted_labels, probabilities
            ):
                actual = int(self.y_test[index])
                writer.writerow(
                    [
                        int(index),
                        int(predicted),
                        self.CLASS_NAMES[predicted],
                        actual,
                        self.CLASS_NAMES[actual],
                        float(probability_vector[predicted]),
                        bool(predicted == actual),
                    ]
                )

    def _plot_training_history(self) -> None:
        assert self.history is not None
        history = self.history.history
        epoch_numbers = range(1, len(history["loss"]) + 1)

        figure, axes = plt.subplots(1, 2, figsize=(10, 4))
        axes[0].plot(epoch_numbers, history["loss"], marker="o", label="Training")
        axes[0].plot(
            epoch_numbers, history["val_loss"], marker="o", label="Validation"
        )
        axes[0].set(title="Loss", xlabel="Epoch", ylabel="Sparse cross-entropy")
        axes[0].legend()
        axes[0].grid(alpha=0.25)

        axes[1].plot(
            epoch_numbers, history["accuracy"], marker="o", label="Training"
        )
        axes[1].plot(
            epoch_numbers,
            history["val_accuracy"],
            marker="o",
            label="Validation",
        )
        axes[1].set(title="Accuracy", xlabel="Epoch", ylabel="Accuracy")
        axes[1].legend()
        axes[1].grid(alpha=0.25)

        figure.suptitle("Python CNN Training History", fontweight="bold")
        figure.tight_layout()
        figure.savefig(
            self.output_dir / "python_training_history.png",
            dpi=180,
            bbox_inches="tight",
        )
        plt.close(figure)

    def _require_data(self) -> None:
        if any(
            value is None
            for value in (self.x_train, self.y_train, self.x_test, self.y_test)
        ):
            raise RuntimeError("Load and prepare the data before this operation.")

    def _require_model(self) -> None:
        if self.model is None:
            raise RuntimeError("Build the model before this operation.")


def parse_arguments() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Train a six-layer Keras CNN on Fashion MNIST."
    )
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", default="outputs")
    parser.add_argument(
        "--indices",
        type=int,
        nargs="+",
        default=[0, 1],
        help="Two or more zero-based test-image indices (default: 0 1).",
    )
    parser.add_argument(
        "--train-limit",
        type=int,
        default=None,
        help="Optional training subset for a quick smoke test; omit for all data.",
    )
    return parser.parse_args()


def main() -> None:
    """Create the classifier and run the end-to-end workflow."""
    arguments = parse_arguments()
    classifier = FashionMNISTCNN(
        epochs=arguments.epochs,
        batch_size=arguments.batch_size,
        seed=arguments.seed,
        output_dir=arguments.output_dir,
        train_limit=arguments.train_limit,
    )
    classifier.run(arguments.indices)


if __name__ == "__main__":
    main()
