"""
Module 4 Assignment: Netflix Data Visualization
Student: Alhaji Sorie Ibrahim Barrie
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. DATA PREPARATION
netflix = pd.read_csv("Netflix_shows_movies.csv")
print("Dataset shape:", netflix.shape)
print("\nColumns:", netflix.columns.tolist())

# 2. DATA CLEANING CHECK
print("\nMissing values after preparation:")
print(netflix.isnull().sum())

# 3. DATA EXPLORATION AND STATISTICAL ANALYSIS
print("\nData types:")
print(netflix.dtypes)
print("\nDescriptive statistics:")
print(netflix.describe(include="all").transpose())
print("\nContent type distribution:")
print(netflix["type"].value_counts())
print("\nRelease year statistics:")
print(netflix["release_year"].describe())
print("\nRatings frequency:")
print(netflix["rating"].value_counts())

# 4A. MOST WATCHED / MOST REPRESENTED GENRES
# No viewing-count variable exists in the supplied data, so title frequency
# is used as a transparent proxy for genre prominence.
genre_counts = (
    netflix["listed_in"].str.split(",").explode().str.strip()
    .value_counts().head(15).sort_values()
)
plt.figure(figsize=(10, 7))
sns.barplot(x=genre_counts.values, y=genre_counts.index, color="steelblue")
plt.title("Most Represented Netflix Genres")
plt.xlabel("Number of Titles")
plt.ylabel("Genre")
plt.tight_layout()
plt.savefig("outputs/most_watched_genres.png", dpi=180)
plt.show()

# 4B. RATINGS DISTRIBUTION
rating_counts = netflix["rating"].value_counts()
plt.figure(figsize=(11, 6))
sns.barplot(x=rating_counts.index, y=rating_counts.values, color="steelblue")
plt.title("Netflix Ratings Distribution")
plt.xlabel("Rating")
plt.ylabel("Number of Titles")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig("outputs/ratings_distribution.png", dpi=180)
plt.show()
