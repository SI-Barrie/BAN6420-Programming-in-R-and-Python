# Module 4 Assignment: Netflix Data Visualization
# R Integration - Ratings Distribution

netflix <- read.csv("Netflix_shows_movies.csv", stringsAsFactors = FALSE)
rating_counts <- sort(table(netflix$rating), decreasing = TRUE)

png("outputs/ratings_distribution_R.png", width = 1200, height = 700)
barplot(
  rating_counts,
  main = "Netflix Ratings Distribution (R)",
  xlab = "Rating",
  ylab = "Number of Titles",
  las = 2,
  cex.names = 0.8
)
dev.off()

print(rating_counts)
