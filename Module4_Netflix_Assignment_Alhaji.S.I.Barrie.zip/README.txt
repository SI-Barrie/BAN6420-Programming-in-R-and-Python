MODULE 4 ASSIGNMENT: NETFLIX DATA VISUALIZATION
================================================

Student: Alhaji Sorie Ibrahim Barrie
Course: BAN6420 - Programming in R & Python
Assignment: Module 4 Assignment - Netflix Data Visualization

OVERVIEW
--------
This submission analyzes the supplied Netflix dataset using Python and implements
one visualization in R. It addresses data preparation, cleaning, exploration,
statistical analysis, visualization, and R integration.

PROJECT CONTENTS
----------------
1. Netflix_shows_movies.csv
   Prepared and cleaned version of the supplied Netflix dataset.

2. netflix_analysis.py
   Python script for exploration, statistical analysis, and visualizations.

3. netflix_visualization.R
   R script that recreates the ratings-distribution visualization.

4. outputs/data_description.csv
   Descriptive summary of the prepared dataset.

5. outputs/most_watched_genres.png
   Python visualization of the 15 most represented genres.

6. outputs/ratings_distribution.png
   Python visualization of the ratings distribution.

DATA PREPARATION AND CLEANING
-----------------------------
The supplied dataset contains 6,234 rows and 12 columns.

Original missing values:
show_id            0
type               0
title              0
director        1969
cast             570
country          476
date_added        11
release_year       0
rating            10
duration           0
listed_in          0
description        0

To retain useful observations, missing director, cast, and country entries were
replaced with "Unknown"; missing ratings with "Not Rated"; and missing date-added
entries with "Unknown". The resulting dataset was saved as Netflix_shows_movies.csv.

DATA EXPLORATION
----------------
The Python analysis:
- reports the dataset dimensions and columns;
- checks missing values and data types;
- generates descriptive statistics;
- examines Movies versus TV Shows;
- summarizes release years; and
- calculates rating frequencies.

VISUAL ANALYTICS
----------------
Python uses pandas, Seaborn, Matplotlib, and Pyplot.

Most watched genres:
The supplied dataset contains no viewing-count, viewing-hours, or audience variable.
Consequently, literal viewing popularity cannot be measured from this file alone.
The visualization therefore uses the frequency of titles in each genre as a
transparent proxy for genre prominence. Multi-genre entries are split before counting.

Ratings distribution:
The second visualization displays the number of Netflix titles in each rating category.

R INTEGRATION
-------------
The R script reads Netflix_shows_movies.csv and recreates the ratings distribution
as a bar chart. When run, it saves:
outputs/ratings_distribution_R.png

HOW TO RUN PYTHON
-----------------
Requirements:
- Python 3.x
- pandas
- matplotlib
- seaborn

Install packages if necessary:
pip install pandas matplotlib seaborn

Run from the project directory:
python netflix_analysis.py

HOW TO RUN R
------------
Requirement:
- R

Run from the project directory:
Rscript netflix_visualization.R

INTERPRETING THE RESULTS
------------------------
The genre chart identifies the genres most frequently represented in the catalogue.
The ratings chart shows the distribution of titles across content-rating categories.
The descriptive-statistics file provides an additional statistical overview.

SUBMISSION
----------
Extract the ZIP file, retain the folder structure, and run the Python and R scripts
from the project root. The ZIP contains the dataset, source code, README, and outputs
needed to review the assignment.
