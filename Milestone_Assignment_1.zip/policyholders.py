
class Policyholder:
    def __init__(self, policy_id, name):
        self.policy_id=policy_id
        self.name=name
        self.status="Active"
        self.product=None
        self.payment_status="Unpaid"

    def register(self):
        self.status="Active"

    def suspend(self):
        self.status="Suspended"

    def reactivate(self):
        self.status="Active"

    def assign_product(self,product):
        self.product=product

    def mark_paid(self):
        self.payment_status="Paid"

    def details(self):
        return {
            "Policy ID":self.policy_id,
            "Name":self.name,
            "Status":self.status,
            "Product":self.product.name if self.product else "None",
            "Payment":self.payment_status
        }
