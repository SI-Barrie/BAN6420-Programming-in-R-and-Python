
class Payment:
    def process_payment(self, policyholder):
        policyholder.mark_paid()
        return f"Payment processed for {policyholder.name}"

    def send_reminder(self, policyholder):
        return f"Reminder sent to {policyholder.name}"

    def apply_penalty(self, policyholder, amount):
        return f"Penalty of ${amount:.2f} applied to {policyholder.name}"
