
class Product:
    def __init__(self, product_id, name, premium):
        self.product_id=product_id
        self.name=name
        self.premium=premium
        self.active=True

    def update(self,name=None,premium=None):
        if name: self.name=name
        if premium is not None: self.premium=premium

    def suspend(self):
        self.active=False

    def activate(self):
        self.active=True
