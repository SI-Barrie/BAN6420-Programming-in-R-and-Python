
from policyholder import Policyholder
from product import Product
from payment import Payment

product=Product("PR001","Comprehensive Health Plan",250)

p1=Policyholder("PH001","John Kamara")
p2=Policyholder("PH002","Aminata Conteh")

for p in (p1,p2):
    p.assign_product(product)

pay=Payment()
pay.process_payment(p1)
pay.process_payment(p2)

print("Policyholder Account Details")
for p in (p1,p2):
    print("-"*30)
    for k,v in p.details().items():
        print(f"{k}: {v}")
