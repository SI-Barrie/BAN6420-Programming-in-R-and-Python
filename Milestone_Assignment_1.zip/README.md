Policy Management System for an Insurance Company

Milestone Assignment 1 – Module 3

Object-Oriented Programming in Python

------------------------------------------------------------------------

Student Information

Student Name: Alhaji Sorie Ibrahim Barrie

Course: Module 3 – Object-Oriented Programming in Python

Assignment: Milestone Assignment 1 – Policy Management System for an
Insurance Company

Submission Date: July 2026

------------------------------------------------------------------------

Assignment Overview

This project was developed to satisfy the requirements of Milestone
Assignment 1 for Module 3.

The objective of the assignment is to design and implement a simple
Policy Management System using the principles of Object-Oriented
Programming (OOP) in Python.

The system allows an insurance company to:

-   Register policyholders
-   Suspend policyholders
-   Reactivate policyholders
-   Create insurance products
-   Update insurance products
-   Suspend insurance products
-   Process premium payments
-   Send payment reminders
-   Apply payment penalties
-   Display policyholder account details

------------------------------------------------------------------------

Project Structure

    PolicyManagementSystem/
    │
    ├── policyholder.py
    ├── product.py
    ├── payment.py
    ├── main.py
    └── README.md

------------------------------------------------------------------------

Description of Each File

policyholder.py

Contains the Policyholder class with methods: - register() - suspend() -
reactivate() - assign_product() - mark_paid() - details()

product.py

Contains the Product class with methods: - Constructor - update() -
suspend() - activate()

payment.py

Contains the Payment class with methods: - process_payment() -
send_reminder() - apply_penalty()

main.py

Demonstrates: - Creating an insurance product - Creating two
policyholders - Assigning a product - Processing payments - Displaying
account details

------------------------------------------------------------------------

Assignment Requirements Addressed

-   ✔ Separate classes created
-   ✔ Policyholder management implemented
-   ✔ Payment management implemented
-   ✔ Product management implemented
-   ✔ Two policyholders demonstrated
-   ✔ Account details displayed

------------------------------------------------------------------------

Software Requirements

-   Python 3.10 or later
-   No external libraries required

------------------------------------------------------------------------

How to Run

    python main.py

------------------------------------------------------------------------

Expected Output

The program displays: - Policyholder ID - Name - Status - Product -
Payment Status

for two policyholders who have successfully paid for an insurance
product.

------------------------------------------------------------------------

OOP Concepts Demonstrated

-   Classes and Objects
-   Constructors
-   Instance Attributes
-   Methods
-   Encapsulation
-   Object Interaction

------------------------------------------------------------------------

Author

Alhaji Sorie Ibrahim Barrie

Milestone Assignment 1

Module 3 – Object-Oriented Programming in Python
