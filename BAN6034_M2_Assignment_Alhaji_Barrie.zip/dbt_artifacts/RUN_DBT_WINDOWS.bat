@echo off
py -m pip install dbt-duckdb
if errorlevel 1 exit /b 1

dbt seed --profiles-dir .
if errorlevel 1 exit /b 1

dbt run --profiles-dir .
if errorlevel 1 exit /b 1

dbt test --profiles-dir .
pause
