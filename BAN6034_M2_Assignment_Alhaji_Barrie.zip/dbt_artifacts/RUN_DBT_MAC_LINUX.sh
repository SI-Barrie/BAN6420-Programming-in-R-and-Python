#!/usr/bin/env bash
set -e
python3 -m pip install dbt-duckdb
dbt seed --profiles-dir .
dbt run --profiles-dir .
dbt test --profiles-dir .
