with source as (
    select *
    from {{ ref('module2_customer_purchases_raw') }}
),

standardized as (
    select
        upper(trim(custID)) as customer_id,
        upper(trim(custName)) as customer_name,

        case
            when lower(trim(Age)) = 'thirty' then 30
            when try_cast(trim(Age) as integer) between 1 and 120
                then try_cast(trim(Age) as integer)
            else null
        end as age,

        case regexp_replace(lower(trim(Product)), '\\s+', ' ', 'g')
            when 'laptop' then 'Laptop'
            when 'lap top' then 'Laptop'
            when 'head phones' then 'Headphones'
            when 'headphones' then 'Headphones'
            when 'keyboard' then 'Keyboard'
            when 'mouse' then 'Mouse'
            when 'monitor' then 'Monitor'
            when 'webcam' then 'Webcam'
            when 'docking station' then 'Docking Station'
            else trim(Product)
        end as product,

        coalesce(
            cast(try_strptime(trim(DatePurchased), '%Y-%m-%d') as date),
            cast(try_strptime(trim(DatePurchased), '%d/%m/%Y') as date),
            cast(try_strptime(trim(DatePurchased), '%B %d, %Y') as date),
            cast(try_strptime(trim(DatePurchased), '%Y/%m/%d') as date)
        ) as date_purchased,

        case
            when try_cast(regexp_replace(trim(Price), '[,$]', '', 'g') as decimal(12,2)) > 0
                then try_cast(regexp_replace(trim(Price), '[,$]', '', 'g') as decimal(12,2))
            else null
        end as price,

        case
            when try_cast(trim(RatingOfProduct) as integer) between 1 and 5
                then try_cast(trim(RatingOfProduct) as integer)
            else null
        end as rating_of_product,

        case lower(trim(AdvertisingAgency))
            when 'google' then 'Google'
            when 'google ads' then 'Google'
            when 'facebook' then 'Facebook'
            when 'fb' then 'Facebook'
            when 'linkedin' then 'LinkedIn'
            when 'email' then 'Email'
            when 'referral' then 'Referral'
            else null
        end as advertising_agency
    from source
)

-- DISTINCT removes the exact duplicate C001 row. The two C007 rows are retained
-- because their prices differ and the raw data has no transaction ID proving that
-- either record is erroneous.
select distinct *
from standardized
