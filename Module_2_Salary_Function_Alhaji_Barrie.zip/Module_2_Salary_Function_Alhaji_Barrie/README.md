# Module 2 Assignment: Salary Function

**Student:** Alhaji Sorie Ibrahim Barrie  
**Course:** BAN6420 Programming in R & Python

## Project Overview

This project uses the San Francisco Salaries dataset to demonstrate Python data
processing, dictionaries, reusable functions, exception handling, CSV export,
ZIP file handling, and R file extraction.

The original assignment instructions are contained in the supplied Module 2
assignment document.

## Dataset

The project uses the **SF Salaries** dataset, which contains annual compensation
records for San Francisco city employees from 2011 to 2014.

Kaggle sources:

- Notebook specified in the assignment:
  `https://www.kaggle.com/code/itshorus/sf-salary`
- Dataset page:
  `https://www.kaggle.com/datasets/kaggle/sf-salaries`

The full `Salaries.csv` file is not duplicated in this submission package because
it is a large third-party dataset. The notebook supports two methods:

1. Place `Salaries.csv` in the same folder as the notebook; or
2. Install `kagglehub` and allow the notebook to download the dataset.

## Project Files

- `Module_2_Salary_Function.ipynb` — complete Jupyter Notebook.
- `salary_function.py` — standalone Python version of the program.
- `unzip_employee_profile.R` — R script for extracting and displaying the CSV.
- `Employee Profile.zip` — example employee profile archive.
- `Employee Profile/NATHANIEL_FORD_Profile.csv` — example exported profile.
- `requirements.txt` — required Python packages.
- `README.md` — instructions for using the project.

## Requirements

- Python 3.9 or later
- Jupyter Notebook or JupyterLab
- R 4.0 or later
- Internet access for automatic Kaggle download, unless `Salaries.csv` is
  already stored locally

Install the Python packages by running:

```bash
pip install -r requirements.txt
```

## How to Run the Jupyter Notebook

1. Extract this project ZIP file.
2. Open a command prompt or terminal in the extracted project folder.
3. Optionally download `Salaries.csv` from Kaggle and place it in the project
   folder.
4. Start Jupyter:

```bash
jupyter notebook
```

5. Open `Module_2_Salary_Function.ipynb`.
6. Select **Kernel > Restart & Run All**.
7. Change the following example name to search for another employee:

```python
employee_name_to_search = "NATHANIEL FORD"
```

8. The notebook will create:
   - an `Employee Profile` folder;
   - an employee CSV file; and
   - `Employee Profile.zip`.

## How to Run the Standalone Python Script

From the project folder, run:

```bash
python salary_function.py
```

The script loads the dataset, builds the employee dictionary, searches for
`NATHANIEL FORD`, exports the employee details, and creates the ZIP archive.

## How to Run the R Script

The Python notebook or script must be run first so that `Employee Profile.zip`
exists.

In RStudio:

1. Open `unzip_employee_profile.R`.
2. Set the working directory to the project folder.
3. Select **Source**.

From an R terminal:

```r
source("unzip_employee_profile.R")
```

The script will:

1. create `Employee Profile Unzipped`;
2. unzip `Employee Profile.zip`;
3. read the employee CSV file; and
4. display the employee details and data structure.

## Error Handling Included

The solution handles:

- missing or empty CSV files;
- improperly formatted CSV files;
- missing required columns;
- blank employee names;
- non-text employee-name inputs;
- employee names not found in the dataset;
- file permission problems; and
- missing ZIP or CSV files in R.

## Submission

Submit the project ZIP file or upload the extracted project folder to a GitHub
repository. The repository should retain this README file and the project
structure.
