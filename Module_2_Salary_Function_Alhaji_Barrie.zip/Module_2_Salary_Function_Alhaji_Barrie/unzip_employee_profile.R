# Module 2 Assignment: Unzip and Display Employee Profile
# Student: Alhaji Sorie Ibrahim Barrie

# Define the ZIP file and extraction folder.
zip_file <- "Employee Profile.zip"
output_folder <- "Employee Profile Unzipped"

tryCatch({

  if (!file.exists(zip_file)) {
    stop(
      paste(
        "The file", zip_file,
        "was not found. Run the Python notebook first."
      )
    )
  }

  # Create the extraction folder when it does not already exist.
  if (!dir.exists(output_folder)) {
    dir.create(output_folder, recursive = TRUE)
  }

  # Unzip the employee profile.
  unzip(zip_file, exdir = output_folder)

  # Locate the exported CSV file.
  csv_files <- list.files(
    output_folder,
    pattern = "\\.csv$",
    full.names = TRUE,
    recursive = TRUE
  )

  if (length(csv_files) == 0) {
    stop("No CSV file was found in the extracted folder.")
  }

  # Read and display each employee profile.
  for (csv_file in csv_files) {
    employee_profile <- read.csv(
      csv_file,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )

    cat("\nEmployee profile loaded from:\n", csv_file, "\n\n")
    print(employee_profile)
    cat("\nStructure of the employee profile:\n")
    str(employee_profile)
  }

}, error = function(error) {
  cat("R processing error:", conditionMessage(error), "\n")
})
