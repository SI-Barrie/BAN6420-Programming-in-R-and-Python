"""
Module 2 Assignment: Salary Function
Student: Alhaji Sorie Ibrahim Barrie
"""

from pathlib import Path
import zipfile
import pandas as pd


def load_salary_data(file_name="Salaries.csv"):
    """Load the SF Salaries dataset from a local file or Kaggle."""
    local_path = Path(file_name)

    try:
        if local_path.exists():
            salary_df = pd.read_csv(local_path, low_memory=False)
        else:
            try:
                import kagglehub
                download_folder = Path(
                    kagglehub.dataset_download("kaggle/sf-salaries")
                )
                matches = list(download_folder.rglob("Salaries.csv"))
                if not matches:
                    raise FileNotFoundError("Salaries.csv was not downloaded.")
                salary_df = pd.read_csv(matches[0], low_memory=False)
            except Exception as error:
                raise FileNotFoundError(
                    "Place Salaries.csv in this project folder or configure "
                    "Kaggle access for kagglehub."
                ) from error

        required = {"EmployeeName", "JobTitle", "TotalPayBenefits", "Year"}
        missing = required.difference(salary_df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")

        salary_df["EmployeeName"] = (
            salary_df["EmployeeName"].astype(str).str.strip()
        )
        return salary_df

    except pd.errors.EmptyDataError as error:
        raise ValueError("The salary CSV file is empty.") from error
    except pd.errors.ParserError as error:
        raise ValueError("The salary CSV file could not be parsed.") from error


def create_employee_dictionary(dataframe):
    """Create a dictionary keyed by normalized employee name."""
    if not isinstance(dataframe, pd.DataFrame):
        raise TypeError("Salary data must be a pandas DataFrame.")
    if dataframe.empty:
        raise ValueError("The salary DataFrame is empty.")

    employee_dictionary = {}
    for record in dataframe.to_dict(orient="records"):
        key = str(record["EmployeeName"]).strip().casefold()
        employee_dictionary.setdefault(key, []).append(record)

    return employee_dictionary


def get_employee_details(employee_name, employee_dictionary):
    """Return all records matching the employee name."""
    try:
        if not isinstance(employee_name, str):
            raise TypeError("Employee name must be text.")

        cleaned_name = " ".join(employee_name.split())
        if not cleaned_name:
            raise ValueError("Employee name cannot be blank.")

        records = employee_dictionary.get(cleaned_name.casefold())
        if records is None:
            raise LookupError(f"No exact record found for '{cleaned_name}'.")

        return pd.DataFrame(records).sort_values("Year").reset_index(drop=True)

    except (TypeError, ValueError, LookupError) as error:
        print(f"Employee search error: {error}")
        return pd.DataFrame()


def export_employee_profile(employee_name, employee_dictionary):
    """Export an employee profile to CSV and ZIP."""
    details = get_employee_details(employee_name, employee_dictionary)

    if details.empty:
        print("No profile was exported.")
        return

    output_folder = Path("Employee Profile")
    output_folder.mkdir(exist_ok=True)

    safe_name = "".join(
        character if character.isalnum() else "_"
        for character in employee_name
    ).strip("_")

    csv_path = output_folder / f"{safe_name}_Profile.csv"
    details.to_csv(csv_path, index=False)

    zip_path = Path("Employee Profile.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(csv_path, arcname=csv_path.name)

    print(f"CSV saved to: {csv_path.resolve()}")
    print(f"ZIP saved to: {zip_path.resolve()}")


if __name__ == "__main__":
    try:
        salary_data = load_salary_data()
        employee_records = create_employee_dictionary(salary_data)
        export_employee_profile("NATHANIEL FORD", employee_records)
    except (FileNotFoundError, ValueError, TypeError, KeyError) as error:
        print(f"Program error: {error}")
